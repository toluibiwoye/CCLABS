#include "Semaphore.h"
/*! \class Semaphore
    \brief A Semaphore Implementation using C++11 features such as mutex and condition variables.

    This class provides a simple implementation of a semaphore using mutex and condition variables.
*/

/**
 * @brief Wait for the semaphore to be signaled.
 */
void Semaphore::Wait()
{
    std::unique_lock<std::mutex> lock(m_mutex);
    m_condition.wait(lock, [&]() -> bool { return m_uiCount > 0; });
    --m_uiCount;
}

/**
 * @brief Wait for the semaphore with a specified relative time.
 * @tparam R Type representing the number of ticks in the duration.
 * @tparam P Type representing the period of the duration.
 * @param crRelTime The relative time to wait for the semaphore.
 * @return True if the semaphore was successfully acquired within the specified time, false otherwise.
 */
template <typename R, typename P>
bool Semaphore::Wait(const std::chrono::duration<R, P> &crRelTime)
{
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_condition.wait_for(lock, crRelTime, [&]() -> bool { return m_uiCount > 0; }))
    {
        return false;
    }
    --m_uiCount;
    return true;
}

/**
 * @brief Signal the semaphore.
 */
void Semaphore::Signal()
{
    std::unique_lock<std::mutex> lock(m_mutex);
    ++m_uiCount;
    m_condition.notify_one();
}

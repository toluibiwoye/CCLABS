#include "SafeBuffer.h"
#include "Event.h"
#include <iostream>
#include <thread>
#include <vector>
#include <memory>

/**
 * @file main.cpp
 * @brief Main file for the producer-consumer demonstration.
 */

// Define constants for the number of producers, consumers, and events.
const int NUM_PRODUCERS = 2;
const int NUM_CONSUMERS = 2;
const int NUM_EVENTS = 20;

// Function prototypes for producer and consumer.
void producer(std::shared_ptr<SafeBuffer<std::shared_ptr<Event>>> theBuffer, int numLoops);
void consumer(std::shared_ptr<SafeBuffer<std::shared_ptr<Event>>> theBuffer, int numLoops);

/**
 * @brief Main function to demonstrate producer-consumer interaction.
 * @return 0 on successful execution.
 */
int main() {
    // Create vectors to hold producer and consumer threads.
    std::vector<std::thread> producers, consumers;
   
    // Create a shared pointer to a SafeBuffer object.
    std::shared_ptr<SafeBuffer<std::shared_ptr<Event>>> aBuffer(new SafeBuffer<std::shared_ptr<Event>>());

    // Create producer threads and add them to the producers vector.
    for (int i = 0; i < NUM_PRODUCERS; ++i) {
        producers.emplace_back(producer, aBuffer, NUM_EVENTS);
    }

    // Create consumer threads and add them to the consumers vector.
    for (int i = 0; i < NUM_CONSUMERS; ++i) {
        consumers.emplace_back(consumer, aBuffer, NUM_EVENTS);
    }

    // Join the producer threads with the main thread.
    for (auto &producer : producers) {
        producer.join();
    }

    // Join the consumer threads with the main thread.
    for (auto &consumer : consumers) {
        consumer.join();
    }

    return 0;
}

/**
 * @brief Producer function that creates events and adds them to the buffer.
 * @param theBuffer The shared buffer for events.
 * @param numLoops The number of iterations for the producer.
 */
void producer(std::shared_ptr<SafeBuffer<std::shared_ptr<Event>>> theBuffer, int numLoops) {
    for (int i = 0; i < numLoops; ++i) {
        // Create a shared pointer to an Event object and add it to the buffer.
        std::shared_ptr<Event> e = std::make_shared<Event>(i);
        theBuffer->put(e);
    }
}

/**
 * @brief Consumer function that gets events from the buffer and consumes them.
 * @param theBuffer The shared buffer for events.
 * @param numLoops The number of iterations for the consumer.
 */
void consumer(std::shared_ptr<SafeBuffer<std::shared_ptr<Event>>> theBuffer, int numLoops) {
    for (int i = 0; i < numLoops; ++i) {
        // Get a shared pointer to an Event object from the buffer and consume the event.
        std::shared_ptr<Event> e = theBuffer->get();
        e->consume();
    }
}

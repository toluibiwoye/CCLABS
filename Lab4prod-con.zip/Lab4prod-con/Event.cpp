#include "Event.h"
#include <iostream>

/**
 * @file Event.cpp
 * @brief Implementation of the Event class.
 */

/**
 * @brief Constructor for the Event class.
 * @param id The unique identifier for the event.
 */
Event::Event(int id) : id(id) {}

/**
 * @brief Consume the event and print its ID.
 */
void Event::consume() {
    std::cout << "Consumed event with ID: " << id << std::endl;
}


# Project Licence:> https://spdx.org/licenses/MIT.html </i> 
# Authors of Project:
**Student:** - Tolu Ibiwoye
**Lecturer** - Joseph Kehoe
**Student Number:** - C00243451
**Institution** - South East Technological University
**Date** - 06/11/2023
**This Lab demonstrates Producer and Consumer**

# How to install project
**Run - `make ALL`**
**Run - `./prodCon`**

## List of any required Libraries, platform issues, etc.:

**Linux** - Environment
**g++** - Compiler
**vs code** - Editor
**make** - For creating MakeFile
**gdb** - Debugger
**doxygen** - Code documentation

## List of files and what they contain:
**main.cpp** - The main project class.
**Semaphore.cpp** - Contains the Semaphore class implementation.
**Semaphore.h** - Header file that contains the Semaphore class that holds the count.
**SafeBuffer.h** - Header file containing the SafeBuffer class template.
**Event.h** - Header file containing the Event class.
**Event.cpp** - Contains the Event class implementation.
**MakeFile** - Compiles the program.
**README** - Information about the lab file.
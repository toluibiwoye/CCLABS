var main_8cpp =
[
    [ "consumer", "main_8cpp.html#adf559bba569b893050b45c5816644446", null ],
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "producer", "main_8cpp.html#af036a2fce3faacc2e34da767c4b19c0c", null ],
    [ "NUM_CONSUMERS", "main_8cpp.html#af7ea883f2308a8ed174ea1894479ec74", null ],
    [ "NUM_EVENTS", "main_8cpp.html#a5da6d9ec042926de0511396589d1a77a", null ],
    [ "NUM_PRODUCERS", "main_8cpp.html#a6d52d339d565ecaed80ad507e5ef2abb", null ]
];
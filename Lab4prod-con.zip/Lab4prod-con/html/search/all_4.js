var searchData=
[
  ['num_5fconsumers_8',['NUM_CONSUMERS',['../main_8cpp.html#af7ea883f2308a8ed174ea1894479ec74',1,'main.cpp']]],
  ['num_5fevents_9',['NUM_EVENTS',['../main_8cpp.html#a5da6d9ec042926de0511396589d1a77a',1,'main.cpp']]],
  ['num_5fproducers_10',['NUM_PRODUCERS',['../main_8cpp.html#a6d52d339d565ecaed80ad507e5ef2abb',1,'main.cpp']]]
];

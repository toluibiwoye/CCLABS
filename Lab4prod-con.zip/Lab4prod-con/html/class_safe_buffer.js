var class_safe_buffer =
[
    [ "get", "class_safe_buffer.html#afdba533e3a5ce1d4e75be05bf6410c96", null ],
    [ "put", "class_safe_buffer.html#abcc6bddc8f887a743d24361132264c17", null ]
];
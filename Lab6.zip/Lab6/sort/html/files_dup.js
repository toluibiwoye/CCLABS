var files_dup =
[
    [ "quicksort.cpp", "quicksort_8cpp.html", "quicksort_8cpp" ]
];
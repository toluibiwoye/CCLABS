// quicksort.cpp --- Parallel Quicksort
// 
// Filename: quicksort.cpp
// Description: Implements parallel quicksort algorithm using OpenMP.
// Author: Joseph Kehoe
// Maintainer: Tolu
// Created: Sat Feb  9 16:43:33 2019 (+0000)
// Version: 
// Package-Requires: ()
// Last-Updated: Tue Feb 12 16:48:22 2019 (+0000)
//           By: Tolu
//     Update #: 103
// URL: 
// Doc URL: 
// Keywords: quicksort, parallel sorting, OpenMP, C++
// Compatibility: 
// 
// 

// Commentary: 
// This program implements the parallel quicksort algorithm using OpenMP.
// It divides the array into partitions and sorts each partition concurrently.
// The tasks are spawned using OpenMP tasks.

// Change Log:
// 
// 
// 
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with GNU Emacs.  If not, see <http://www.gnu.org/licenses/>.
//
// 

// Code:

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <complex>      /* complex number data type */
#include <time.h>       /* time */
#include <functional>   /* function type */
#include <limits>
#include <vector>      /* vectors used instead of arrays */

using namespace std;

const int LENGTH = 2000;

/**
 * @brief Partition the array into two segments.
 * 
 * @param myArray The array to partition.
 * @param low The lower bound of the partition.
 * @param high The upper bound of the partition.
 * @return int The pivot position.
 */
int partition(vector<int>& myArray, int low, int high);

/**
 * @brief Recursively perform quicksort on the array using OpenMP tasks.
 * 
 * @param myArray The array to sort.
 * @param low The lower bound of the array.
 * @param high The upper bound of the array.
 * @return int Returns 1.
 */
int quicksort(vector<int>& myArray, int low, int high);

int main(void);

// 
// quicksort.cpp ends here


// saxpy.cpp --- SAXPY Operation
// 
// Filename: saxpy.cpp
// Description: Performs the SAXPY operation and measures the execution time.
// Author: Joseph Kehoe
// Maintainer: Tolu
// Created: 20/11/23 (+0000)
// Version: 
// Package-Requires: ()
// Last-Updated: 20/11/23 (+0000)
//           By: Tolu
// Update #: 25
// URL: 
// Doc URL: 
// Keywords: SAXPY, linear algebra, parallel programming, C++
// Compatibility: 
// 
// 

// Commentary: 
// This program performs the SAXPY (Single-precision A*X Plus Y) operation,
// where it multiplies each element of vector x by a constant factor 'a'
// and adds the result to the corresponding element of vector y.

// Change Log:
// 
// 
// 
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with GNU Emacs.  If not, see <http://www.gnu.org/licenses/>.
// 
// 

// Code:

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <limits>

/**
 * @brief Performs the SAXPY operation.
 * 
 * @param n The size of the vectors.
 * @param a The constant factor.
 * @param y The output vector.
 * @param x The input vector.
 */
void saxpy(unsigned long n, float a, float y[], float x[]);

int main(void);

// 
// saxpy.cpp ends here


// mandelbroit.cpp --- Mandelbrot set generation
// 
// Filename: mandelbroit.cpp
// Description: Generates the Mandelbrot set and measures the execution time.
// Author: Joseph
// Maintainer: Tolu 
// Created: Mon Feb  4 09:40:41 2019 (+0000)
// Version: 
// Package-Requires: ()
// Last-Updated: Mon 20/11/2023 (+0000)
//           By: Tolu
// Update #: 18
// URL: 
// Doc URL: 
// Keywords: Mandelbrot, set, generation, C++
// Compatibility: 
// 
// 

// Commentary: 
// This program generates the Mandelbrot set and measures the execution time.

// Change Log:
// 
// 
// 
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with GNU Emacs.  If not, see <http://www.gnu.org/licenses/>.
// 
// 

// Code:

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <complex>      /* complex number data type */
#include <time.h>       /* time */
#include <limits>

using namespace std ;

const int ROW = 1000;
const int COL = 1000;
const int DEPTH = 10;

/**
 * @brief Calculates the Mandelbrot set value for a given complex number.
 * 
 * @param c The complex number for which the Mandelbrot set value is calculated.
 * @param depth The maximum number of iterations for the calculation.
 * @return int The Mandelbrot set value for the given complex number.
 */
int calc(complex<int> c, int depth);

/**
 * @brief Generates the Mandelbrot set.
 * 
 * @param p The 2D array to store the Mandelbrot set values.
 * @param depth The maximum number of iterations for the calculation.
 */
void mandel(int p[ROW][COL], int depth);

int main(void);

// 
// mandelbroit.cpp ends here


var files_dup =
[
    [ "mandelbroit.cpp", "mandelbroit_8cpp.html", "mandelbroit_8cpp" ],
    [ "saxpy.cpp", "saxpy_8cpp.html", "saxpy_8cpp" ]
];
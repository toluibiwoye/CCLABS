var mandelbroit_8cpp =
[
    [ "calc", "mandelbroit_8cpp.html#a90efdf8cc6afbd58cf8c363528e55155", null ],
    [ "main", "mandelbroit_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "mandel", "mandelbroit_8cpp.html#a714bf111c48a34bc7463c91153b491a1", null ],
    [ "COL", "mandelbroit_8cpp.html#ade5776b4151c77e0c375d1091dae8978", null ],
    [ "DEPTH", "mandelbroit_8cpp.html#a58b87c2251946d94f6a6dc43572db440", null ],
    [ "ROW", "mandelbroit_8cpp.html#a442a526f05e8429d610b777bb0a4446b", null ]
];
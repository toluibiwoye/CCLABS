var searchData=
[
  ['saxpy_9',['saxpy',['../saxpy_8cpp.html#a8c812fc93b815fd11479e6b6f259a4ef',1,'saxpy.cpp']]],
  ['saxpy_2ecpp_10',['saxpy.cpp',['../saxpy_8cpp.html',1,'']]]
];

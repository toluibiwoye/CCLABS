var searchData=
[
  ['calc_0',['calc',['../mandelbroit_8cpp.html#a90efdf8cc6afbd58cf8c363528e55155',1,'mandelbroit.cpp']]],
  ['col_1',['COL',['../mandelbroit_8cpp.html#ade5776b4151c77e0c375d1091dae8978',1,'mandelbroit.cpp']]]
];

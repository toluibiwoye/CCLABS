var searchData=
[
  ['main_15',['main',['../mandelbroit_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;mandelbroit.cpp'],['../saxpy_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;saxpy.cpp']]],
  ['mandel_16',['mandel',['../mandelbroit_8cpp.html#a714bf111c48a34bc7463c91153b491a1',1,'mandelbroit.cpp']]]
];

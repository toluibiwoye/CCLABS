var searchData=
[
  ['readme_2emd_7',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['row_8',['ROW',['../mandelbroit_8cpp.html#a442a526f05e8429d610b777bb0a4446b',1,'mandelbroit.cpp']]]
];

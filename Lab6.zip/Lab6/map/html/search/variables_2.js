var searchData=
[
  ['row_20',['ROW',['../mandelbroit_8cpp.html#a442a526f05e8429d610b777bb0a4446b',1,'mandelbroit.cpp']]]
];

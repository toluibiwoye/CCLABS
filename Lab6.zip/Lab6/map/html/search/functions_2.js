var searchData=
[
  ['saxpy_17',['saxpy',['../saxpy_8cpp.html#a8c812fc93b815fd11479e6b6f259a4ef',1,'saxpy.cpp']]]
];

var searchData=
[
  ['calc_14',['calc',['../mandelbroit_8cpp.html#a90efdf8cc6afbd58cf8c363528e55155',1,'mandelbroit.cpp']]]
];

var searchData=
[
  ['dim_12',['DIM',['../stencil_8cpp.html#a589b8b9bfdf714f736059845d568b597',1,'stencil.cpp']]]
];

var searchData=
[
  ['size_13',['SIZE',['../stencil_8cpp.html#af08413a3ee12cf78b0ddeea71e2648b3',1,'stencil.cpp']]]
];

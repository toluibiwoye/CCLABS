var searchData=
[
  ['calcneighbours_0',['calcNeighbours',['../stencil_8cpp.html#a16cd13f0a990612823638d179af32bdb',1,'stencil.cpp']]]
];

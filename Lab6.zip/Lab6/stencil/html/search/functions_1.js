var searchData=
[
  ['getnewvalue_9',['getNewValue',['../stencil_8cpp.html#a6d6a4c1769d6dd5c00d3c0fb296988fa',1,'stencil.cpp']]]
];

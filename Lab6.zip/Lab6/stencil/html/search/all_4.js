var searchData=
[
  ['size_4',['SIZE',['../stencil_8cpp.html#af08413a3ee12cf78b0ddeea71e2648b3',1,'stencil.cpp']]],
  ['stencil_5',['stencil',['../stencil_8cpp.html#acef790ec25e4b2af503275c95153adbc',1,'stencil.cpp']]],
  ['stencil_2ecpp_6',['stencil.cpp',['../stencil_8cpp.html',1,'']]]
];

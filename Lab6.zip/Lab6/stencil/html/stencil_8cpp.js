var stencil_8cpp =
[
    [ "calcNeighbours", "stencil_8cpp.html#a16cd13f0a990612823638d179af32bdb", null ],
    [ "getNewValue", "stencil_8cpp.html#a6d6a4c1769d6dd5c00d3c0fb296988fa", null ],
    [ "main", "stencil_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "stencil", "stencil_8cpp.html#acef790ec25e4b2af503275c95153adbc", null ],
    [ "DIM", "stencil_8cpp.html#a589b8b9bfdf714f736059845d568b597", null ],
    [ "SIZE", "stencil_8cpp.html#af08413a3ee12cf78b0ddeea71e2648b3", null ]
];
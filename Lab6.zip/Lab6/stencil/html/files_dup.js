var files_dup =
[
    [ "stencil.cpp", "stencil_8cpp.html", "stencil_8cpp" ]
];
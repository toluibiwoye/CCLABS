// stencil.cpp --- 
// 
// Filename: stencil.cpp
// Description: Implementation of the stencil operation using vectors and functions.
// Author: Joseph
// Maintainer: Tolu
// Created: 23/11/23 (+0000)
// Version: 
// Package-Requires: ()
// Last-Updated: 23/11/23 (+0000)
//           By: Tolu
// Update #: 40
// URL: 
// Doc URL: 
// Keywords: stencil, vector, function, C++
// Compatibility: 
// 
// 

// Commentary: 
// This program demonstrates the implementation of the stencil operation using C++ vectors and functions.
// The stencil operation is a common computational pattern used in various scientific and parallel programming applications.
// It involves updating each element of an array (or vector) based on the values of its neighbors, typically using a given function.

// Change Log:
// 
// 

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with GNU Emacs.  If not, see <http://www.gnu.org/licenses/>.
// 

// Code:

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <complex>      /* complex number data type */
#include <time.h>       /* time */
#include <functional>   /* function type */
#include <limits>
#include <vector>      /* vectors used instead of arrays */

using namespace std;

//array dimension
const int DIM = 1000;
const int SIZE = 4;

/**
 * @brief Calculates the neighbors of a given index in the input vector.
 * 
 * @param in Input vector.
 * @param index Index for which neighbors are to be calculated.
 * @param out Vector to store the neighbors.
 * @return int Returns 1.
 */
int calcNeighbours(vector<float> const &in, int index, vector<float> &out);

/**
 * @brief Applies the stencil operation to the input vector.
 * 
 * @param in Input vector.
 * @param out Output vector.
 * @param f Stencil function to apply.
 * @param size Size of the stencil.
 */
void stencil(vector<float> const &in, vector<float> &out,
             function<float(vector<float>)> f, int size);

/**
 * @brief Stencil function to calculate the average of current values.
 * 
 * @param currentValues Vector of current values.
 * @return float Average of current values.
 */
float getNewValue(vector<float> currentValues);

/**
 * @brief Main function to demonstrate the stencil operation.
 * 
 * @return int Returns 0 on success.
 */
int main(void);

// 
// stencil.cpp ends here



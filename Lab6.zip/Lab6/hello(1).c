// helloThreads.cpp --- 
// 
// Filename: helloThreads.cpp
// Description: 
// Author: Joseph
// Maintainer: Tolu
// Created: Sun Oct 22 20:36:51 2023 (+0100)
// Last-Updated: Sun Oct 22 20:37:01 2023 (+0100)
//           By: Joseph
//     Update #: 1
// 
// 

// Commentary: 
// 
// This program is a simple example demonstrating the use of OpenMP to print "Hello World"
// from multiple threads. It utilizes the OpenMP parallel region to distribute the work
// among available threads, each printing its own "Hello World" message.

// Code:

// OpenMP program to print Hello World
// using C language

// OpenMP header
#include <omp.h>

#include <stdio.h>
#include <stdlib.h>

/// \brief The main function that prints "Hello World" from each thread in a parallel region.
/// \param argc The number of command line arguments.
/// \param argv The array of command line arguments.
/// \return 0 on successful execution.
int main(int argc, char* argv[])
{

    // Beginning of parallel region
    #pragma omp parallel
    {

        printf("Hello World... from thread = %d\n",
            omp_get_thread_num());
    }
    // Ending of parallel region
}


// 
// helloThreads.cpp ends here


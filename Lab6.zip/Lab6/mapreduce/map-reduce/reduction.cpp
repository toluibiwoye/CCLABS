// reduction.cpp --- 
// 
// Filename: quicksort.cpp
// Description: Implementation of parallel summation of a vector using OpenMP.
// Author: Joseph Kehoe
// Maintainer: Tolu
// Created: Sat Feb 19 13:23:33 2019 (+0000)
// Version: 
// Package-Requires: ()
// Last-Updated: nov 22 20:51:32 2023 (+0100)
//           By: Tolu
// Update #: 106
// URL: 
// Doc URL: 
// Keywords: parallel, summation, vector, OpenMP, C++
// Compatibility: 
// 
// 

// Commentary: 
// This program implements parallel summation of a vector using OpenMP.
// It provides three different methods to calculate the sum: serial, parallel, and tiled parallel.
// The OpenMP parallel and reduction clauses are utilized for efficient parallelization.
// The program outputs the average values for each method, allowing for comparison.

// Change Log:
// 
// 
// 
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with GNU Emacs.  If not, see <http://www.gnu.org/licenses/>.
//
// 

// Code:

#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <complex>      /* complex number data type */
#include <time.h>       /* time */
#include <functional>  /* function type */
#include <limits>
#include <vector>      /* vectors used instead of arrays */
#include <omp.h>
using namespace std ;

const int LENGTH = 2000;
int NumThreads = 1;

/// \brief Find out how many threads are running!
/// \return The number of running threads.
int get_num_threads(void);

/// \brief Get the sum of elements in a vector in a serial manner.
/// \param data The vector of integers.
/// \return The sum of the elements.
float getSerialSum(vector<int> data);

/// \brief Get the sum of elements in a vector in a parallel manner using OpenMP.
/// \param data The vector of integers.
/// \return The sum of the elements.
float getParallelSum(vector<int> data);

/// \brief Get the sum of elements in a vector in a tiled parallel manner using OpenMP.
/// \param data The vector of integers.
/// \return The sum of the elements.
float getTiledParallelsum(vector<int> data);

int main(void);

// 
// reduction.cpp ends here



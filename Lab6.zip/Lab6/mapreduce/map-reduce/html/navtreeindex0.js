var NAVTREEINDEX0 =
{
"files.html":[0,0],
"globals.html":[0,1,0],
"globals_func.html":[0,1,1],
"globals_vars.html":[0,1,2],
"index.html":[],
"pages.html":[],
"reduction_8cpp.html":[0,0,0],
"reduction_8cpp.html#a31821d51dd484c9a9ef1f0d911920b2d":[0,0,0,2],
"reduction_8cpp.html#a64e8554d4459a361ede8620d842ee3e2":[0,0,0,1],
"reduction_8cpp.html#a761d3655563c63c0b8b291be491291dc":[0,0,0,6],
"reduction_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe":[0,0,0,4],
"reduction_8cpp.html#aa01f1f55a817fa34c952af9917c6f2f3":[0,0,0,3],
"reduction_8cpp.html#aa07caf85cdcdc69bc138cb903c343f52":[0,0,0,5],
"reduction_8cpp.html#ab6b513132f81d9de1ab9578e8a02dfe1":[0,0,0,0]
};

var reduction_8cpp =
[
    [ "get_num_threads", "reduction_8cpp.html#ab6b513132f81d9de1ab9578e8a02dfe1", null ],
    [ "getParallelSum", "reduction_8cpp.html#a64e8554d4459a361ede8620d842ee3e2", null ],
    [ "getSerialSum", "reduction_8cpp.html#a31821d51dd484c9a9ef1f0d911920b2d", null ],
    [ "getTiledParallelsum", "reduction_8cpp.html#aa01f1f55a817fa34c952af9917c6f2f3", null ],
    [ "main", "reduction_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "LENGTH", "reduction_8cpp.html#aa07caf85cdcdc69bc138cb903c343f52", null ],
    [ "NumThreads", "reduction_8cpp.html#a761d3655563c63c0b8b291be491291dc", null ]
];
var files_dup =
[
    [ "reduction.cpp", "reduction_8cpp.html", "reduction_8cpp" ]
];
var searchData=
[
  ['get_5fnum_5fthreads_0',['get_num_threads',['../reduction_8cpp.html#ab6b513132f81d9de1ab9578e8a02dfe1',1,'reduction.cpp']]],
  ['getparallelsum_1',['getParallelSum',['../reduction_8cpp.html#a64e8554d4459a361ede8620d842ee3e2',1,'reduction.cpp']]],
  ['getserialsum_2',['getSerialSum',['../reduction_8cpp.html#a31821d51dd484c9a9ef1f0d911920b2d',1,'reduction.cpp']]],
  ['gettiledparallelsum_3',['getTiledParallelsum',['../reduction_8cpp.html#aa01f1f55a817fa34c952af9917c6f2f3',1,'reduction.cpp']]]
];

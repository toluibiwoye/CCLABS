var searchData=
[
  ['numthreads_6',['NumThreads',['../reduction_8cpp.html#a761d3655563c63c0b8b291be491291dc',1,'reduction.cpp']]]
];

var searchData=
[
  ['reduction_2ecpp_7',['reduction.cpp',['../reduction_8cpp.html',1,'']]]
];

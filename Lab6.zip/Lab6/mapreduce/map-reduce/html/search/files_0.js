var searchData=
[
  ['reduction_2ecpp_8',['reduction.cpp',['../reduction_8cpp.html',1,'']]]
];

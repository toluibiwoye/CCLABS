/**
 * @file main.cpp
 * @brief Main function demonstrating the usage of a reusable barrier.
 */

#include "Barrier.h"
#include <iostream>
#include <thread>
#include <vector>
#include <memory>

static const int num_threads = 100;
int sharedVariable = 0;

/**
 * @brief Task function for updating shared resources.
 *
 * An example of using a reusable barrier. Displays a message that is split into
 * two sections to show how a rendezvous works.
 *
 * @param theBarrier A shared pointer to the Barrier object.
 * @param numLoops The number of loops to perform the task.
 */
void updateTask(std::shared_ptr<Barrier> theBarrier, int numLoops) {
    for (int i = 0; i < numLoops; ++i) {
        // Do the first part of the task
        std::cout << "A" << i;

        // Barrier synchronization
        theBarrier->semaphoreA();

        // Do the second part of the task
        std::cout << "B" << i;

        // Barrier synchronization
        theBarrier->semaphoreB();
    }
}

/**
 * @brief Main function demonstrating the usage of a reusable barrier.
 *
 * Launches multiple threads to perform the updateTask and demonstrates the
 * synchronization using the Barrier class.
 *
 * @return 0 on successful execution.
 */
int main(void) {
    // Vector to store thread objects
    std::vector<std::thread> vt(num_threads);

    // Shared pointer to the Barrier object
    std::shared_ptr<Barrier> aBarrier(new Barrier(num_threads));

    // Launch the threads
    for (std::thread& t : vt) {
        t = std::thread(updateTask, aBarrier, 10);
    }

    // Join the threads with the main thread
    for (auto& v : vt) {
        v.join();
    }

    // Output the value of the shared variable
    std::cout << sharedVariable << std::endl;

    return 0;
}

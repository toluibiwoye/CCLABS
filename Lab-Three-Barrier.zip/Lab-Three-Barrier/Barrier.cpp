/**
 * @file Barrier.cpp
 * @brief Implementation of the Barrier class.
 */

#include "Barrier.h"
#include <iostream>

/**
 * @brief Destructor for the Barrier class.
 */
Barrier::~Barrier() { }

/**
 * @brief Semaphore A for the Barrier class.
 *
 * Increments the number of threads and performs synchronization based on the specified phases.
 * If all threads have arrived, signals the next phase and resets the count.
 */
void Barrier::semaphoreA() {
    mutex.Wait();
    numThreads++;

    if (numThreads == threadTotal) {
        std::cout << std::endl;
        phase2.Wait();
        phase1.Signal();
    }

    mutex.Signal();
    phase1.Wait();
    phase1.Signal();
}

/**
 * @brief Semaphore B for the Barrier class.
 *
 * Decrements the number of threads and performs synchronization based on the specified phases.
 * If all threads have arrived, signals the next phase and resets the count.
 */
void Barrier::semaphoreB() {
    mutex.Wait();
    numThreads--;

    if (numThreads == 0) {
        std::cout << std::endl;
        phase1.Wait();
        phase2.Signal();
    }

    mutex.Signal();
    phase2.Wait();
    phase2.Signal();
}

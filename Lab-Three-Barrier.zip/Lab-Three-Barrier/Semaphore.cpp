/**
 * @file Semaphore.cpp
 * @brief Implementation of the Semaphore class.
 */

#include "Semaphore.h"

/**
 * @class Semaphore
 * @brief A Semaphore Implementation.
 *
 * Uses C++11 features such as mutex and condition variables to implement Semaphore.
 */

/**
 * @brief Waits until the semaphore is signaled.
 *
 * This function blocks the calling thread until the semaphore is signaled.
 */
void Semaphore::Wait()
{
    std::unique_lock<std::mutex> lock(m_mutex);
    m_condition.wait(lock, [&]() -> bool { return m_uiCount > 0; });
    --m_uiCount;
}

/**
 * @brief Waits until the semaphore is signaled or until a specified timeout.
 *
 * This function blocks the calling thread until the semaphore is signaled or
 * until the specified relative time duration has passed.
 *
 * @tparam R Type representing the number of ticks in the relative time.
 * @tparam P Type representing the period of the relative time.
 * @param crRelTime The maximum duration for which the function will block.
 * @return true if the semaphore was signaled, false if the timeout occurred.
 */
template <typename R, typename P>
bool Semaphore::Wait(const std::chrono::duration<R, P>& crRelTime)
{
    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_condition.wait_for(lock, crRelTime, [&]() -> bool { return m_uiCount > 0; })) {
        return false;
    }
    --m_uiCount;
    return true;
}

/**
 * @brief Signals the semaphore, allowing one waiting thread to proceed.
 */
void Semaphore::Signal()
{
    std::unique_lock<std::mutex> lock(m_mutex);
    ++m_uiCount;
    m_condition.notify_one();
}

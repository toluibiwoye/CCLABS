
# Project Licence: <i> https://spdx.org/licenses/MIT.html </i>

# Authors of Project:
**Student:** - Tolu Ibiwoye
**Lecturer** - Joseph Kehoe
**Student Number:** - C00243451
**Institution** - South East Technological University
**Date** - 01/11/2023
**This Lab demonstrates Resusable Barrier**

# How to install project
**Run - `make ALL`**
**Run - `./a.out`**

## List of any required Libraries, platform issues, etc.:

**Linux** - Environment
**g++** - Compiler
**vs code** - Editor
**make** - For creating MakeFile
**gdb** - Debugger
**doxygen** - Code documentation

## List of files and what they contain:
**main.cpp** - The main project class.
**Semaphore.cpp** - Contains the Semaphore class implementation.
**Semaphore.h** - Header file that contains the Semaphore class that holds the count.
**Barrier.cpp** - Contains the Barrier class.
**Barrier.h** - CHeader file that contains the Barrier class.
**MakeFile** - Compiles the program.
**README** - Information about the lab file.
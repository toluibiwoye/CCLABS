#pragma once
#include "Semaphore.h"

class Barrier{
  int numThreads;
  int threadTotal;
  
  Semaphore mutex{1}; //mutex lock
  Semaphore phase1{0}; 
  Semaphore phase2{1};
  
public:
  Barrier(int totalThreads){
    numThreads = 0;
    threadTotal = totalThreads;
  };
  //constructor
  virtual ~Barrier();
  void semaphoreA();
  void semaphoreB(); 
}; 

/* Barrier.h ends here */
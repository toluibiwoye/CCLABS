var searchData=
[
  ['sharedvariable_34',['sharedVariable',['../main_8cpp.html#a2d5b01367ae1267dfac47c7875aac5e4',1,'main.cpp']]]
];

var searchData=
[
  ['project_20licence_3a_20_3ci_3e_20https_3a_2f_2fspdx_2eorg_2flicenses_2fmit_2ehtml_20_3c_2fi_3e_35',['Project Licence: &lt;i&gt; https://spdx.org/licenses/MIT.html &lt;/i&gt;',['../md__read_me.html',1,'']]]
];

var files_dup =
[
    [ "Barrier.cpp", "_barrier_8cpp.html", null ],
    [ "Barrier.h", "_barrier_8h.html", [
      [ "Barrier", "class_barrier.html", "class_barrier" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Semaphore.cpp", "_semaphore_8cpp.html", null ],
    [ "Semaphore.h", "_semaphore_8h.html", [
      [ "Semaphore", "class_semaphore.html", "class_semaphore" ]
    ] ]
];
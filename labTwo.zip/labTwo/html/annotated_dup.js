var annotated_dup =
[
    [ "Semaphore", "class_semaphore.html", "class_semaphore" ],
    [ "Signal", "class_signal.html", null ]
];
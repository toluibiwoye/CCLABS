var searchData=
[
  ['readme_2emd_2',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rendezvous_2ecpp_3',['rendezvous.cpp',['../rendezvous_8cpp.html',1,'']]]
];

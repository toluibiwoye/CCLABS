/**
 * @file Semaphore.h
 * @brief Declaration of the Semaphore class.
 */

#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#include <mutex>
#include <condition_variable>
#include <chrono>

/**
 * @class Semaphore
 * @brief A Semaphore Implementation.
 *
 * Uses C++11 features such as mutex and condition variables to implement Semaphore.
 */
class Semaphore {
private:
    unsigned int m_uiCount; /**< Holds the Semaphore count */
    std::mutex m_mutex; /**< Mutex to protect the Semaphore state. */
    std::condition_variable m_condition; /**< Condition variable for waiting threads. */

public:
    /**
     * @brief Constructor for Semaphore.
     * @param uiCount Initial count for the Semaphore (default is 0).
     */
    Semaphore(unsigned int uiCount = 0);

    /**
     * @brief Waits until the semaphore is signaled.
     *
     * This function blocks the calling thread until the semaphore is signaled.
     */
    void Wait();

    /**
     * @brief Waits until the semaphore is signaled or until a specified timeout.
     *
     * This function blocks the calling thread until the semaphore is signaled or
     * until the specified relative time duration has passed.
     *
     * @tparam R Type representing the number of ticks in the relative time.
     * @tparam P Type representing the period of the relative time.
     * @param crRelTime The maximum duration for which the function will block.
     * @return true if the semaphore was signaled, false if the timeout occurred.
     */
    template <typename R, typename P>
    bool Wait(const std::chrono::duration<R, P>& crRelTime);

    /**
     * @brief Signals the semaphore, allowing one waiting thread to proceed.
     */
    void Signal();
};

#endif // SEMAPHORE_H

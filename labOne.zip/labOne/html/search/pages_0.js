var searchData=
[
  ['project_20licence_3a_19',['Project Licence:',['../md__r_e_a_d_m_e.html',1,'']]]
];

# Project Licence:
<i> https://spdx.org/licenses/MIT.html </i>

# Authors of Project:
**Student:** - Tolu Ibiwoye
**Lecturer** - Joseph Kehoe
**Student Number:** - C00243451
**Institution** - South East Technological University
**Date** - 21/10/2023
**This Lab demonstrates Mutal Exclusion**

# How to install project
**Run - `make ALL`**
**Run - `./my_program`**

## List of any required Libraries, platform issues, etc.:

**Linux** - Environment
**g++** - Compiler
**vs code** - Editor
**make** - For creating MakeFile
**doxygen** - Code documentation

## List of files and what they contain:
 **mutualEx.cpp** - the main project class.
 **semaphore.cpp** - manages the threads.
 **semaphore.h** - header file that contains the semaphore class that holds the count.
 **MakeFile** - compilies the program.
 **README** - information about the lab file.
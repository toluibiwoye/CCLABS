#include "Semaphore.h"
#include <iostream>
#include <thread>
#include <vector>

static const int num_threads = 100;
Semaphore mutexExclusion(1);
static int sharedVariable = 0; // it can only be accessed from within the file in which it is declared.

/*! \fn updateTask
    \brief An Implementation of Mutual Exclusion using Semaphores.

    This function demonstrates mutual exclusion using semaphores to update a shared variable.

    @param firstSem A shared pointer to a Semaphore object.
    @param numUpdates The number of updates each thread should perform.
*/
void updateTask(std::shared_ptr<Semaphore> firstSem, int numUpdates)
{
    for (int i = 0; i < numUpdates; i++)
    {
        mutexExclusion.Wait();
        std::cout << sharedVariable << std::endl;
        sharedVariable++;
        mutexExclusion.Signal();
        // UPDATE SHARED VARIABLE HERE!
    }
}

/**
 * @brief Main function that launches threads to demonstrate mutual exclusion.
 * @return 0 on successful completion.
 */
int main(void)
{
    std::vector<std::thread> vt(num_threads);
    std::shared_ptr<Semaphore> aSemaphore(new Semaphore);

    /**< Launch the threads */
    int i = 0;
    for (std::thread &t : vt)
    {
        t = std::thread(updateTask, aSemaphore, 1000);
    }
    std::cout << "Launched from the main\n";

    /**< Join the threads with the main thread */
    for (auto &v : vt)
    {
        v.join();
    }

    std::cout << sharedVariable << std::endl;
    return 0;
}

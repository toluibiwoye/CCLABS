/**
 * @file helloThreads.cpp
 * @brief A simple program demonstrating the usage of a Semaphore with threads.
 */

#include "Semaphore.h"
#include <iostream>
#include <thread>
#include <unistd.h>

/**
 * @brief Represents a task that prints messages with a delay.
 * @param theSemaphore A shared pointer to the Semaphore object.
 * @param delay The delay in seconds before printing.
 */
void taskOne(std::shared_ptr<Semaphore> theSemaphore, int delay);

/**
 * @brief Represents a task that prints messages.
 * @param theSemaphore A shared pointer to the Semaphore object.
 */
void taskTwo(std::shared_ptr<Semaphore> theSemaphore);

/**
 * @brief The main function of the program.
 * @return 0 on successful execution.
 */
int main(void);

/**
 * @brief Represents a task that prints messages with a delay.
 *
 * This function represents a task that prints messages with a delay and signals
 * that it has completed using the provided Semaphore.
 *
 * @param theSemaphore A shared pointer to the Semaphore object.
 * @param delay The delay in seconds before printing.
 */
void taskOne(std::shared_ptr<Semaphore> theSemaphore, int delay) {
    sleep(delay);
    std::cout << "I ";
    std::cout << "must ";
    std::cout << "print ";
    std::cout << "first" << std::endl;
    theSemaphore->Signal();  // Signal that taskOne has completed
}

/**
 * @brief Represents a task that prints messages.
 *
 * This function represents a task that prints messages and waits for a signal
 * from the provided Semaphore.
 *
 * @param theSemaphore A shared pointer to the Semaphore object.
 */
void taskTwo(std::shared_ptr<Semaphore> theSemaphore) {
    std::cout << "This ";
    std::cout << "will ";
    sleep(5);
    std::cout << "appear ";
    std::cout << "second" << std::endl;
}

/**
 * @brief The main function of the program.
 * @return 0 on successful execution.
 */
int main(void) {
    std::thread threadOne, threadTwo;
    std::shared_ptr<Semaphore> sem(new Semaphore);
    sem->Signal();
    sem->Wait(); // these serve no purpose

    /**< Launch the threads */
    int taskOneDelay = 5;
    threadOne = std::thread(taskTwo, sem);
    threadTwo = std::thread(taskOne, sem, taskOneDelay);
    std::cout << "Launched from the main\n";

    /**< Wait for the threads to finish */
    threadOne.join();
    threadTwo.join();
    return 0;
}

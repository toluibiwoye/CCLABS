/**
 * @file test1.cpp
 * @brief A simple C++ program to print numbers from 0 to 9.
 */

#include <iostream>

/**
 * @brief The main function of the program.
 * @return 0 on successful execution.
 */
int main() {
    int i; /**< Loop counter variable. */

    /**
     * @brief Loop to print numbers from 0 to 9.
     *
     * The loop iterates from 0 to 9 and prints each number.
     */
    for (i = 0; i < 10; i++) {
        std::cout << i; /**< Print the current number. */
    }

    return 0;
}

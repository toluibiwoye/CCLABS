var main_8cpp =
[
    [ "eat", "main_8cpp.html#a228fa031b8deb86a9df2eea2892c3241", null ],
    [ "forks", "main_8cpp.html#a1203c5e7c4716e863dc085f2ea69815e", null ],
    [ "get_forks", "main_8cpp.html#a21a9defcc14025ebcaa9484d47622b9d", null ],
    [ "main", "main_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "philosopher", "main_8cpp.html#a61d704a6f65c3d915b82ea8a844cc527", null ],
    [ "put_forks", "main_8cpp.html#a4cec90aab433a1e4df09b9b6662d5c3e", null ],
    [ "think", "main_8cpp.html#a995feefa383b82265e681a3fe8c012c2", null ],
    [ "COUNT", "main_8cpp.html#a308572e3937ef7742e8cc93025faf712", null ],
    [ "EATTIME", "main_8cpp.html#a92e894dc749f0caa8232e432965090af", null ],
    [ "THINKTIME", "main_8cpp.html#a5a1bc6e8c62cf965547cd9bba4da2448", null ]
];
var searchData=
[
  ['get_5fforks_25',['get_forks',['../main_8cpp.html#a21a9defcc14025ebcaa9484d47622b9d',1,'main.cpp']]]
];

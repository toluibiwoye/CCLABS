var searchData=
[
  ['philosopher_27',['philosopher',['../main_8cpp.html#a61d704a6f65c3d915b82ea8a844cc527',1,'main.cpp']]],
  ['put_5fforks_28',['put_forks',['../main_8cpp.html#a4cec90aab433a1e4df09b9b6662d5c3e',1,'main.cpp']]]
];

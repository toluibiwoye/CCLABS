#include "Semaphore.h"

/*! \class Semaphore
    \brief A Semaphore Implementation

    This class implements a Semaphore using C++11 features such as mutex and condition variables.

    It provides a mechanism to control access to a shared resource by multiple threads.

    Usage:
    - To acquire (wait) a resource, use Wait() or Wait(const std::chrono::duration<R,P>& crRelTime).
    - To release (signal) a resource, use Signal().

    \note This implementation assumes proper usage and does not include error handling for simplicity.
*/

void Semaphore::Wait()
{
    /// Acquires a resource.
    /// If the count is zero, the thread will wait until the count becomes greater than zero.

    std::unique_lock<std::mutex> lock(m_mutex);
    m_condition.wait(lock, [&]() -> bool { return m_uiCount > 0; });
    --m_uiCount;
}

template <typename R, typename P>
bool Semaphore::Wait(const std::chrono::duration<R, P>& crRelTime)
{
    /// Acquires a resource with a timeout.
    /// If the count is zero, the thread will wait until the count becomes greater than zero
    /// or until the specified relative timeout duration elapses.

    std::unique_lock<std::mutex> lock(m_mutex);
    if (!m_condition.wait_for(lock, crRelTime, [&]() -> bool { return m_uiCount > 0; }))
    {
        return false; // Timeout
    }
    --m_uiCount;
    return true;
}

void Semaphore::Signal()
{
    /// Releases a resource.
    /// Increments the count and notifies one waiting thread.

    std::unique_lock<std::mutex> lock(m_mutex);
    ++m_uiCount;
    m_condition.notify_one();
}

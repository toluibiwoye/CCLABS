
#ifndef SEMAPHORE_H
#define SEMAPHORE_H 

#include <mutex>
#include <condition_variable>
#include <chrono>

/*! \class Semaphore
    \brief A Semaphore Implementation

    This class provides a Semaphore implementation using C++11 features such as mutex and condition variables.
    A Semaphore is a synchronization primitive used to control access to a shared resource by multiple threads.

    Usage:
    - Initialize with an optional initial count.
    - Use Wait() to acquire (decrement) the Semaphore.
    - Use Wait(const std::chrono::duration<R,P>& crRelTime) for acquiring with a timeout.
    - Use Signal() to release (increment) the Semaphore.

    \note This implementation assumes proper usage and does not include error handling for simplicity.

    \author Your Name
    \date The date
*/

class Semaphore
{
private:
    unsigned int m_uiCount; /*!< Holds the Semaphore count */
    std::mutex m_mutex; /**< Mutex for mutual exclusion */
    std::condition_variable m_condition; /**< Condition variable for waiting threads */

public:
    /*! \brief Constructor for Semaphore.
        \param uiCount Optional initial count for the Semaphore.
    */
    Semaphore(unsigned int uiCount = 0);

    /*! \brief Waits until the Semaphore is available and then acquires it.
    */
    void Wait();

    /*! \brief Waits for the specified relative timeout duration to acquire the Semaphore.
        \param crRelTime The relative timeout duration.
        \return True if the Semaphore was acquired, false if a timeout occurred.
    */
    template <typename R, typename P>
    bool Wait(const std::chrono::duration<R, P>& crRelTime);

    /*! \brief Signals (releases) the Semaphore.
    */
    void Signal();
};

#endif

